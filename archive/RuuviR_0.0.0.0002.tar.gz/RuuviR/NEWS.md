# RuuviR 0.0.0002

## First functions developed to get basic analysis

* plot
* .libpath setup for package development.

# RuuviR 0.0.0001

## First initial version created

* v0001: first version
* read ruuvi sensor csv-data files from a given folder.
- [ ] plot data experiments (ruuvi_temp.R)
