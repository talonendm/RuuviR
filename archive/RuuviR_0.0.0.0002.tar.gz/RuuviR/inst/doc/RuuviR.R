## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(RuuviR)
ruuvidatalocation <- 'C:\\Users\\talon_000\\Dropbox\\2021\\ruuvi\\m210829'

## -----------------------------------------------------------------------------
ruuvi.data <- RuuviR::LoadRuuviExports(
  pathRuuvitag = ruuvidatalocation)

## -----------------------------------------------------------------------------
data.wide <- RuuviR::MakeDataWide(
         data = ruuvi.data,
         timewindow_min = 5,
         tag_name = FALSE
       )

## -----------------------------------------------------------------------------
(RuuviR::PlotRuuvi(data.wide))

