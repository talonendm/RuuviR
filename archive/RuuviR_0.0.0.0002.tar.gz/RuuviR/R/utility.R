# ...........................................................
# utility.R
# ...........................................................
#' hello world example
#'
#' prints information
#'
#' @export
#' @examples
#' helloRuuviR()
helloRuuviR <- function() {
  print("This is R package for Ruuvitag data analysis")
}
# ...........................................................
